<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<title><?php echo $__env->yieldContent('title'); ?> - Bitmovil</title>

<!-- css -->

<link rel="stylesheet" href="<?php echo e(asset('assets/css/vendor.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
<?php /**PATH /Users/falvizo/Desarrollo de Software/LaravelProjects/BMWPv1/resources/views/layout/partials/head.blade.php ENDPATH**/ ?>