<?php $__env->startSection('title', 'Control de acceso'); ?> <!--Personaliza el título del conenido de la página-->
<?php $__env->startSection('content'); ?>

    <!-- contenido html aquí -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/falvizo/Desarrollo de Software/LaravelProjects/BMWPv1/resources/views/video.blade.php ENDPATH**/ ?>