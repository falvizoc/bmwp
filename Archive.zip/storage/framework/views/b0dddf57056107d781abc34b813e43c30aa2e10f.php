<!-- scripts -->
<script src="<?php echo e(asset('assets/js/vendor.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
<script src="https://unpkg.com/ionicons@5.1.2/dist/ionicons.js"></script>

<script>
    $(function(){
        $('.carousel').carousel({
            interval: 9000
        })
    });
</script>
<?php /**PATH /Users/falvizo/Desarrollo de Software/LaravelProjects/BMWPv1/resources/views/layouts/partials/footer-scripts.blade.php ENDPATH**/ ?>