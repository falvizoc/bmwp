<?php $__env->startSection('title', 'Transformación Digital'); ?> <!--Personaliza el título del conenido de la página-->
<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/falvizo/Desarrollo de Software/LaravelProjects/BMWPv1/resources/views/main.blade.php ENDPATH**/ ?>