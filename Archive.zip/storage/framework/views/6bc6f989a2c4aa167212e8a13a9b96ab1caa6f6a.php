<div class="container">
    <div class="gallery " style="padding-top: 105px;">
        <div class="gallery-container">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <div class="image image-overlay" style="background-image:url(<?php echo e(asset('assets/img/banners/laptops.jpg')); ?>)">
                    </div>
                    <div class="caption text-white" data-swiper-parallax="-100%">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col">
                                    <span class="eyebrow">Santorini, Greece</span>
                                    <h1 class="display-3">Mediterannian <br>Ressort & Spa</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="image image-overlay" style="background-image:url(<?php echo e(asset('assets/img/banners/hikvisionThermals.jpg')); ?>)">
                    </div>
                    <div class="caption text-white" data-swiper-parallax="-100%">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col">
                                    <span class="eyebrow">Santorini, Greece</span>
                                    <h1 class="display-3">Mediterannian <br>Ressort & Spa</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="image image-overlay" style="background-image:url(<?php echo e(asset('assets/img/banners/hikvisionThermals.jpg')); ?>)">
                    </div>
                    <div class="caption text-white" data-swiper-parallax="-100%">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col">
                                    <span class="eyebrow">Santorini, Greece</span>
                                    <h1 class="display-3">Mediterannian <br>Ressort & Spa</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="image image-overlay" style="background-image:url(<?php echo e(asset('assets/img/banners/hikvisionThermals.jpg')); ?>)">
                    </div>
                    <div class="caption text-white" data-swiper-parallax="-100%">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col">
                                    <span class="eyebrow">Santorini, Greece</span>
                                    <h1 class="display-3">Mediterannian <br>Ressort & Spa</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                ...
            </div>
        </div>
        <div class="gallery-thumbs">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <h5>Santorini, Greece</h5>
                </div>
                <div class="swiper-slide">
                    <h5>Santorini, Greece</h5>
                </div>
                <div class="swiper-slide">
                    <h5>Santorini, Greece</h5>
                </div>
                <div class="swiper-slide">
                    <h5>Santorini, Greece</h5>
                </div>
                <div class="swiper-slide">
                    <h5>Santorini, Greece</h5>
                </div>
                ...
            </div>
        </div>
    </div>

</div>
<?php /**PATH /Users/falvizo/Desarrollo de Software/LaravelProjects/BMWPv1/resources/views/layout/partials/slider.blade.php ENDPATH**/ ?>