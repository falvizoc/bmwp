<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<title>@yield('title') - Bitmovil</title>

<!-- css -->

<link rel="stylesheet" href="{{asset('assets/css/vendor.css')}}">
<link rel="stylesheet" href="{{asset('assets/css/app.css')}}">
<link rel="stylesheet" href="{{asset('assets/css/style.css')}}">
