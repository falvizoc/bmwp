@extends('mainlayout')
@section('title', 'Transformación Digital') <!--Personaliza el título del conenido de la página-->
@section('content')

@endsection

