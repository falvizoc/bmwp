@extends('layout')
@section('title', 'Control de acceso') <!--Personaliza el título del conenido de la página-->
@section('content')

    <!-- contenido html aquí -->

@endsection
